package hangman;
import java.io.File;
import java.io.*;
import java.util.SortedSet;
import java.util.TreeSet;


public class EvilHangman {

    public static void main(String[] args) throws IOException, EmptyDictionaryException, GuessAlreadyMadeException {
        File textFile = new File(args[0]);
        int theWordLength = Integer.parseInt(args[1]);
        int maxNumberOfWrongGuess = Integer.parseInt(args[2]);

        EvilHangmanGame myEvilHangmanGame = new EvilHangmanGame();
        myEvilHangmanGame.startGame(textFile, theWordLength);
        SortedSet<Character> guessLettersByPlayer = new TreeSet<>();
//        System.out.println(myEvilHangmanGame.wordSet);
//
        myEvilHangmanGame.makeGuess('o');
//
//
//        String myString = "aba";
//        char myChar = 'a';
//
//        String myKey = myEvilHangmanGame.getSubsetKey(myString,myChar);
//        System.out.println(myKey);

//
//        while(maxNumberOfWrongGuess != 0){
//            System.out.println("You have " + maxNumberOfWrongGuess + " guesses left");
//            guessLettersByPlayer = myEvilHangmanGame.getGuessedLetters();
//            System.out.println("Used letters: " + guessLettersByPlayer);
//
//
//
//
//            maxNumberOfWrongGuess --;
//        }


    }
}

package hangman;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Set;
import java.util.SortedSet;
import java.util.Scanner;
import java.util.*;


public class EvilHangmanGame implements IEvilHangmanGame{

  Set<String> wordSet = new HashSet<String>();
  Set<String> theNewWordSubset = new HashSet<String>();
  SortedSet<Character> guessLettersByPlayer = new TreeSet<>();
  @Override
  public void startGame(File dictionary, int wordLength) throws IOException, EmptyDictionaryException {

    // *** Need to initialize the game everytime we start because the pass off driver plays multiple game *** \\

    Scanner myScanner = new Scanner(dictionary);

    while(myScanner.hasNext()) {
      String wordInDictionary=myScanner.next();
      wordSet.add(wordInDictionary);
    }

    Iterator<String> it = wordSet.iterator(); // this block deletes all words that are not correct length.
    while(it.hasNext()){
      String word = it.next();
      if(word.length() != wordLength) {
        it.remove();
      }
    }

//    System.out.println("these are all the words in the file printed out from a set: \n");
//    for (String str : wordSet) {
//      System.out.println(str);
//    }


  }

  @Override
  public Set<String> makeGuess(char guess) throws GuessAlreadyMadeException {

    HashMap<String, Set<String>> myMapPartitioner = new HashMap<>(); // String subsetKey and Set<String> words in the list that have the subsetted key word.
    for (String str : wordSet) {
      String mySubsetString = getSubsetKey(str, guess);
      if(!myMapPartitioner.containsKey(mySubsetString)){
        myMapPartitioner.put(mySubsetString, new HashSet<>());
      }
      myMapPartitioner.get(mySubsetString).add(str); // get the Hashset from that key.
    }

   String largestKey = getLargestKeyValue(myMapPartitioner);
//
//    System.out.println("This is the largest key:   " + largestKey);


    // now we are going to want to find the subset that has the most words in it
    // then that becomes the new wordSet for the next game
    // what if you have two subsets of the same maximum size? you have to break the tie







//    System.out.println("These are the key-value pairs in the Map: \n");
//    for(Map.Entry <String,Set<String>> mp: myMapPartitioner.entrySet()){
//      System.out.println(mp.getKey() + " " + mp.getValue());
//    }

    return null;
  }

  @Override
  public SortedSet<Character> getGuessedLetters() {
    return guessLettersByPlayer;
  }


  public String getSubsetKey(String word, char guessedLetter){
    // iterate through each char in the word
    // for each word, we calculate the subsetkey
    // AKA it will return the correct word in respect to tje guessedLetter.
    for(int i = 0; i < word.length(); i++){
      if(word.charAt(i) != guessedLetter){
        word = word.replace(word.charAt(i), '_');
      }
    }
    return word;
  }

  public String getLargestKeyValue(Map<String, Set<String>> families){
    // 1. choose the group with no letter at all. (for ex: ____)
    // 2. if the group has the guess letter, choose the group with the smallest amount of guessed letters
    // 3. choose the one with the rightmost guessed letter (for ex: e_e_ or __ee, the second would be chosen)
    // 4. if there is STILL more than one group, choose the one with rightmost letter and continue doing this until 1 group has been chosen.

    int maxCount = 0;
    for(String key: families.keySet()){ // main for loop to iterate over the subsetKeys.

      for(int i = 1; i < families.keySet().size(); i++){// for loop to iterate over each position of the subset string

        if(key.charAt(0) == key.charAt(i)){  // if string is all underscores this will return
          System.out.println("The correct key for tie breaker 1: " + key);
        }

        

      }
    }

return "";

  }




}



//      if(key.matches("^[a-zA-Z]*$")){
//        maxCount++;
//      }

